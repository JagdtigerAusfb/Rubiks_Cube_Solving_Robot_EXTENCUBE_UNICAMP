/* Autores: Pedro Ortolan, Guilherme Ramalho, Paulo Sérgio */

/*Feito como parte do projeto de extensão Extencube para montagem de um robô solucionador de cubo mágico*/

/*

Esse código recebe uma string contendo a série de movimentos que devem ser realizados pelos motores para solucionar
o cubo mágico. A notação da string segue a lógica de caractere único:

Com a face frontal sendo a verde e a superior sendo a branca.

A string de solução usa a seguinte codificação de caractere único:

MOTOR 1 (Pinos 1) - Up (U)
U  -> 'A'  (Anti-Horário 90)
U' -> 'B'  (Horário 90)
U2 -> 'C'  (Anti-Horário 180)

MOTOR 2 (Pinos 2) - Right (R)
R  -> 'D'  (Anti-Horário 90)
R' -> 'E'  (Horário 90)
R2 -> 'F'  (Anti-Horário 180)

MOTOR 3 (Pinos 3) - Front (F)
F  -> 'G'  (Anti-Horário 90)
F' -> 'H'  (Horário 90)
F2 -> 'I'  (Anti-Horário 180)

MOTOR 4 (Pinos 4) - Down (D)
D  -> 'J'  (Anti-Horário 90)
D' -> 'K'  (Horário 90)
D2 -> 'L'  (Anti-Horário 180)

MOTOR 5 (Pinos 5) - Left (L)
L  -> 'M'  (Anti-Horário 90)
L' -> 'N'  (Horário 90)
L2 -> 'O'  (Anti-Horário 180)

MOTOR 6 (Pinos 6) - Back (B)
B  -> 'P'  (Anti-Horário 90)
B' -> 'Q'  (Horário 90)
B2 -> 'R'  (Anti-Horário 180)

O código é divido em 6 blocos: Definições, Set Up, Verificação de opostos, Um motor, Dois motores e Executar.
(O restante da descrição permanece o mesmo)
...
*/

//******************BLOCO 1 - DEFINIÇÕES**************************//
//declaração dos pinos
int DIR_PIN_1 = 2; // Motor 1 (U -> A,B,C)
int STEP_PIN_1 = 3; 

int DIR_PIN_2 = 4; // Motor 2 (R -> D,E,F)
int STEP_PIN_2 = 5; 

int DIR_PIN_3 = 6; // Motor 3 (F -> G,H,I)
int STEP_PIN_3 = 7; 

int DIR_PIN_4 = 8; // Motor 4 (D -> J,K,L)
int STEP_PIN_4 = 9; 

int DIR_PIN_5 = 10; // Motor 5 (L -> M,N,O)
int STEP_PIN_5 = 11; 

int DIR_PIN_6 = 12; // Motor 6 (B -> P,Q,R)
int STEP_PIN_6 = 13; 

int ENABLE_PIN = 21;
//***************************************************************//


//*********************BLOCO 2 - SET UP**************************//
void setup() {

  //Seta pins como output
  
  pinMode(DIR_PIN_1, OUTPUT);
  pinMode(STEP_PIN_1, OUTPUT);
  
  pinMode(DIR_PIN_2, OUTPUT);
  pinMode(STEP_PIN_2, OUTPUT);
  
  pinMode(DIR_PIN_3, OUTPUT);
  pinMode(STEP_PIN_3, OUTPUT);

  pinMode(DIR_PIN_4, OUTPUT);
  pinMode(STEP_PIN_4, OUTPUT);

  pinMode(DIR_PIN_5, OUTPUT);
  pinMode(STEP_PIN_5, OUTPUT);

  pinMode(DIR_PIN_6, OUTPUT);
  pinMode(STEP_PIN_6, OUTPUT);

  pinMode(LED_BUILTIN, OUTPUT);
  pinMode(ENABLE_PIN, OUTPUT);

}


//****************BLOCO 3 - GIRAR UM MOTOR**********************************//
// Função roda apenas um motor
void girarmotor(String motor){

    // 1. Define variáveis locais
    int dirPin, stepPin, dir, passos;
    bool moveValido = true;

    // 2. Bloco IF para definir os parâmetros 
    if (motor == "A")      { dirPin = DIR_PIN_1; stepPin = STEP_PIN_1; dir = LOW; passos = 50; }
    else if (motor == "B") { dirPin = DIR_PIN_1; stepPin = STEP_PIN_1; dir = HIGH; passos = 50; }
    else if (motor == "C") { dirPin = DIR_PIN_1; stepPin = STEP_PIN_1; dir = LOW; passos = 100; }

    else if (motor == "D") { dirPin = DIR_PIN_2; stepPin = STEP_PIN_2; dir = LOW; passos = 50; }
    else if (motor == "E") { dirPin = DIR_PIN_2; stepPin = STEP_PIN_2; dir = HIGH; passos = 50; }
    else if (motor == "F") { dirPin = DIR_PIN_2; stepPin = STEP_PIN_2; dir = LOW; passos = 100; }

    else if (motor == "G") { dirPin = DIR_PIN_3; stepPin = STEP_PIN_3; dir = LOW; passos = 50; }
    else if (motor == "H") { dirPin = DIR_PIN_3; stepPin = STEP_PIN_3; dir = HIGH; passos = 50; }
    else if (motor == "I") { dirPin = DIR_PIN_3; stepPin = STEP_PIN_3; dir = LOW; passos = 100; }

    else if (motor == "J") { dirPin = DIR_PIN_4; stepPin = STEP_PIN_4; dir = LOW; passos = 50; }
    else if (motor == "K") { dirPin = DIR_PIN_4; stepPin = STEP_PIN_4; dir = HIGH; passos = 50; }
    else if (motor == "L") { dirPin = DIR_PIN_4; stepPin = STEP_PIN_4; dir = LOW; passos = 100; }

    else if (motor == "M") { dirPin = DIR_PIN_5; stepPin = STEP_PIN_5; dir = LOW; passos = 50; }
    else if (motor == "N") { dirPin = DIR_PIN_5; stepPin = STEP_PIN_5; dir = HIGH; passos = 50; }
    else if (motor == "O") { dirPin = DIR_PIN_5; stepPin = STEP_PIN_5; dir = LOW; passos = 100; }

    else if (motor == "P") { dirPin = DIR_PIN_6; stepPin = STEP_PIN_6; dir = LOW; passos = 50; }
    else if (motor == "Q") { dirPin = DIR_PIN_6; stepPin = STEP_PIN_6; dir = HIGH; passos = 50; }
    else if (motor == "R") { dirPin = DIR_PIN_6; stepPin = STEP_PIN_6; dir = LOW; passos = 100; }

    else { moveValido = false; } // Comando inválido

    // 3. Bloco de Execução (só executa se o comando for válido)
    if (moveValido) {
      digitalWrite (dirPin, dir); 

      for (int i = 0; i < passos; i++) 
      {
      digitalWrite(stepPin, HIGH); 
      digitalWrite(LED_BUILTIN, HIGH);
      delayMicroseconds(1000);          
      digitalWrite(stepPin, LOW); 
      digitalWrite(LED_BUILTIN, LOW);
      delayMicroseconds(1000);          
      }
    }
}
//***************************************************************//


//*****BLOCO 4 - VERIFICA OPOSTOS*************************************//
// Verifica se são opostos 
// A lógica checa os grupos de letras, que representam faces opostas (U/D, F/B, R/L)
// A,B,C (U) é oposto de J,K,L (D)
// G,H,I (F) é oposto de P,Q,R (B)
// D,E,F (R) é oposto de M,N,O (L)
bool saoOpostos(String m1, String m2) {

  // Recebe os comandos nas variáveis locais
  char face1 = ' ';
  char face2 = ' ';

  // Apenas se o tamanho for maior que zero (feito por segurança)
  if (m1.length() > 0) { face1 = m1.charAt(0); }
  if (m2.length() > 0) { face2 = m2.charAt(0); }

  // Se um for uma string vazia -> comando ínválido (feito por segurança)
  if (face1 == ' ' || face2 == ' ') { return false; }

  // Define os grupos de faces (define verdade para a face correpondente)
  bool f1_is_U = (face1 == 'A' || face1 == 'B' || face1 == 'C');
  bool f1_is_D = (face1 == 'J' || face1 == 'K' || face1 == 'L');
  bool f1_is_F = (face1 == 'G' || face1 == 'H' || face1 == 'I');
  bool f1_is_B = (face1 == 'P' || face1 == 'Q' || face1 == 'R');
  bool f1_is_R = (face1 == 'D' || face1 == 'E' || face1 == 'F');
  bool f1_is_L = (face1 == 'M' || face1 == 'N' || face1 == 'O');
  
  bool f2_is_U = (face2 == 'A' || face2 == 'B' || face2 == 'C');
  bool f2_is_D = (face2 == 'J' || face2 == 'K' || face2 == 'L');
  bool f2_is_F = (face2 == 'G' || face2 == 'H' || face2 == 'I');
  bool f2_is_B = (face2 == 'P' || face2 == 'Q' || face2 == 'R');
  bool f2_is_R = (face2 == 'D' || face2 == 'E' || face2 == 'F');
  bool f2_is_L = (face2 == 'M' || face2 == 'N' || face2 == 'O');


  // Checa os pares opostos (A e B ou B e A)
  if ((f1_is_U && f2_is_D) || (f1_is_D && f2_is_U)) { return true; }
  if ((f1_is_F && f2_is_B) || (f1_is_B && f2_is_F)) { return true; } 
  if ((f1_is_R && f2_is_L) || (f1_is_L && f2_is_R)) { return true; }
  
  return false;
}
//***************************************************************//


//**************************BLOCO 5 - GIRA DOIS MOTORES*************************************//
// Gira dois motores simultaneamente
void girarDoisMotores(String motor1, String motor2) {
  
  // Parâmetros para Motor 1
  int dirPin1, stepPin1, dir1, passos1;
  // Parâmetros para Motor 2
  int dirPin2, stepPin2, dir2, passos2;
  
  bool move1Valido = true;
  bool move2Valido = true;

  // --- Bloco IF para Motor 1 ---
  if (motor1 == "A")      { dirPin1 = DIR_PIN_1; stepPin1 = STEP_PIN_1; dir1 = LOW; passos1 = 50; }
  else if (motor1 == "B") { dirPin1 = DIR_PIN_1; stepPin1 = STEP_PIN_1; dir1 = HIGH; passos1 = 50; }
  else if (motor1 == "C") { dirPin1 = DIR_PIN_1; stepPin1 = STEP_PIN_1; dir1 = LOW; passos1 = 100; }
  
  else if (motor1 == "D") { dirPin1 = DIR_PIN_2; stepPin1 = STEP_PIN_2; dir1 = LOW; passos1 = 50; }
  else if (motor1 == "E") { dirPin1 = DIR_PIN_2; stepPin1 = STEP_PIN_2; dir1 = HIGH; passos1 = 50; }
  else if (motor1 == "F") { dirPin1 = DIR_PIN_2; stepPin1 = STEP_PIN_2; dir1 = LOW; passos1 = 100; }
  
  else if (motor1 == "G") { dirPin1 = DIR_PIN_3; stepPin1 = STEP_PIN_3; dir1 = LOW; passos1 = 50; }
  else if (motor1 == "H") { dirPin1 = DIR_PIN_3; stepPin1 = STEP_PIN_3; dir1 = HIGH; passos1 = 50; }
  else if (motor1 == "I") { dirPin1 = DIR_PIN_3; stepPin1 = STEP_PIN_3; dir1 = LOW; passos1 = 100; }
  
  else if (motor1 == "J") { dirPin1 = DIR_PIN_4; stepPin1 = STEP_PIN_4; dir1 = LOW; passos1 = 50; }
  else if (motor1 == "K") { dirPin1 = DIR_PIN_4; stepPin1 = STEP_PIN_4; dir1 = HIGH; passos1 = 50; }
  else if (motor1 == "L") { dirPin1 = DIR_PIN_4; stepPin1 = STEP_PIN_4; dir1 = LOW; passos1 = 100; }
  
  else if (motor1 == "M") { dirPin1 = DIR_PIN_5; stepPin1 = STEP_PIN_5; dir1 = LOW; passos1 = 50; }
  else if (motor1 == "N") { dirPin1 = DIR_PIN_5; stepPin1 = STEP_PIN_5; dir1 = HIGH; passos1 = 50; }
  else if (motor1 == "O") { dirPin1 = DIR_PIN_5; stepPin1 = STEP_PIN_5; dir1 = LOW; passos1 = 100; }
  
  else if (motor1 == "P") { dirPin1 = DIR_PIN_6; stepPin1 = STEP_PIN_6; dir1 = LOW; passos1 = 50; }
  else if (motor1 == "Q") { dirPin1 = DIR_PIN_6; stepPin1 = STEP_PIN_6; dir1 = HIGH; passos1 = 50; }
  else if (motor1 == "R") { dirPin1 = DIR_PIN_6; stepPin1 = STEP_PIN_6; dir1 = LOW; passos1 = 100; }
  
  else { move1Valido = false; } // Motor 1 inválido

  // --- Bloco IF para Motor 2 ---
  if (motor2 == "A")      { dirPin2 = DIR_PIN_1; stepPin2 = STEP_PIN_1; dir2 = LOW; passos2 = 50; }
  else if (motor2 == "B") { dirPin2 = DIR_PIN_1; stepPin2 = STEP_PIN_1; dir2 = HIGH; passos2 = 50; }
  else if (motor2 == "C") { dirPin2 = DIR_PIN_1; stepPin2 = STEP_PIN_1; dir2 = LOW; passos2 = 100; }
  
  else if (motor2 == "D") { dirPin2 = DIR_PIN_2; stepPin2 = STEP_PIN_2; dir2 = LOW; passos2 = 50; }
  else if (motor2 == "E") { dirPin2 = DIR_PIN_2; stepPin2 = STEP_PIN_2; dir2 = HIGH; passos2 = 50; }
  else if (motor2 == "F") { dirPin2 = DIR_PIN_2; stepPin2 = STEP_PIN_2; dir2 = LOW; passos2 = 100; }
  
  else if (motor2 == "G") { dirPin2 = DIR_PIN_3; stepPin2 = STEP_PIN_3; dir2 = LOW; passos2 = 50; }
  else if (motor2 == "H") { dirPin2 = DIR_PIN_3; stepPin2 = STEP_PIN_3; dir2 = HIGH; passos2 = 50; }
  else if (motor2 == "I") { dirPin2 = DIR_PIN_3; stepPin2 = STEP_PIN_3; dir2 = LOW; passos2 = 100; }
  
  else if (motor2 == "J") { dirPin2 = DIR_PIN_4; stepPin2 = STEP_PIN_4; dir2 = LOW; passos2 = 50; }
  else if (motor2 == "K") { dirPin2 = DIR_PIN_4; stepPin2 = STEP_PIN_4; dir2 = HIGH; passos2 = 50; }
  else if (motor2 == "L") { dirPin2 = DIR_PIN_4; stepPin2 = STEP_PIN_4; dir2 = LOW; passos2 = 100; }
  
  else if (motor2 == "M") { dirPin2 = DIR_PIN_5; stepPin2 = STEP_PIN_5; dir2 = LOW; passos2 = 50; }
  else if (motor2 == "N") { dirPin2 = DIR_PIN_5; stepPin2 = STEP_PIN_5; dir2 = HIGH; passos2 = 50; }
  else if (motor2 == "O") { dirPin2 = DIR_PIN_5; stepPin2 = STEP_PIN_5; dir2 = LOW; passos2 = 100; }
  
  else if (motor2 == "P") { dirPin2 = DIR_PIN_6; stepPin2 = STEP_PIN_6; dir2 = LOW; passos2 = 50; }
  else if (motor2 == "Q") { dirPin2 = DIR_PIN_6; stepPin2 = STEP_PIN_6; dir2 = HIGH; passos2 = 50; }
  else if (motor2 == "R") { dirPin2 = DIR_PIN_6; stepPin2 = STEP_PIN_6; dir2 = LOW; passos2 = 100; }
  
  else { move2Valido = false; } // Motor 2 inválido

  
  if (!move1Valido || !move2Valido) return; // Não faz nada se um dos comandos for inválido
  
  // Seta a direção de ambos
  digitalWrite(dirPin1, dir1);
  digitalWrite(dirPin2, dir2);

  // Pega o maior número de passos (caso um seja 90 e o outro 180)
  int maxPassos = max(passos1, passos2); 

  for (int i = 0; i < maxPassos; i++) {
    
    // Pulsa motor 1 (HIGH) se ele ainda tiver passos
    if (i < passos1) { digitalWrite(stepPin1, HIGH); }
    // Pulsa motor 2 (HIGH) se ele ainda tiver passos
    if (i < passos2) { digitalWrite(stepPin2, HIGH); }
    
    digitalWrite(LED_BUILTIN, HIGH);
    delayMicroseconds(1000); // Delay para ambos

    // Pulsa motor 1 (LOW)
    if (i < passos1) { digitalWrite(stepPin1, LOW); }
    // Pulsa motor 2 (LOW)
    if (i < passos2) { digitalWrite(stepPin2, LOW); }
    
    digitalWrite(LED_BUILTIN, LOW);
    delayMicroseconds(1000); // Delay para ambos
  }
}
//***************************************************************//


//************************BLOCO 6 - CHAMA AS FUNÇÕES***************************************//
void RaidenMk1Executar(String algoritmo[], int numMovimentos) {
  
  int i_movimento = 0; // Usa um índice local
  digitalWrite(ENABLE_PIN, LOW); // Liga os drivers 
  
  // Roda ENQUANTO o índice for menor que o número total de movimentos
  while (i_movimento < numMovimentos) {
    
    // 1. Tenta olhar para frente (i + 1)
    // Compara o atual com o menor menos um, 
    // Se for o último vai ser igual, e não menor
    if (i_movimento < numMovimentos - 1) {

      // Recebe o movimento atual e o próximo
      String moveAtual = algoritmo[i_movimento];
      String proximoMove = algoritmo[i_movimento + 1];

      /* 2. "IF" DE OTIMIZAÇÃO
        Checa se os comandos são em lados opostos,
        chama então a respectiva função */
      if (saoOpostos(moveAtual, proximoMove)) {

        girarDoisMotores(moveAtual, proximoMove);
        i_movimento += 2; // Pula os dois
      } 

      else {

        girarmotor(moveAtual);
        i_movimento++; // Avança só um
      }
    } 

    // 3. É o último movimento da lista (não pode olhar para frente)
    else { 
      girarmotor(algoritmo[i_movimento]);
      i_movimento++; // Avança para terminar
    }

    digitalWrite(ENABLE_PIN, HIGH); // Desliga os drivers entre execuções 
    // MUDE ESSE VALOR PARA ALTERAR O TEMPO ENTRE EXECUÇÕES (elementos do array)
    delay(1000); 
  }
  
}
//***************************************************************//


void loop() {
                  // String antiga: { "F2", "B", "R", "L", "B"}
  String minhaSTRINGsuperBACANA[] = { "I", "P", "D", "M", "P"};      // Define a String
  int numMoves = sizeof(minhaSTRINGsuperBACANA) / sizeof(minhaSTRINGsuperBACANA[0]); // Isso calcula o tamanho

  RaidenMk1Executar(minhaSTRINGsuperBACANA, numMoves);              // EXECUTA
    
}